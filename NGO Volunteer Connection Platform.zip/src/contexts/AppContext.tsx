import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'ngo' | 'volunteer';
  organizationName?: string;
}

export interface Event {
  id: string;
  ngoId: string;
  ngoName: string;
  name: string;
  type: string;
  date: string;
  time: string;
  location: string;
  description: string;
  volunteersNeeded: number;
  photoUrl: string;
  latitude?: number;
  longitude?: number;
}

export interface Registration {
  id: string;
  eventId: string;
  volunteerId: string;
  volunteerName: string;
  phoneNumber: string;
}

interface AppContextType {
  user: User | null;
  users: User[];
  events: Event[];
  registrations: Registration[];
  theme: 'light' | 'dark';
  locationGranted: boolean;
  userLocation: { lat: number; lng: number } | null;
  login: (email: string, password: string) => boolean;
  register: (name: string, email: string, password: string, role: 'ngo' | 'volunteer', organizationName?: string) => boolean;
  logout: () => void;
  addEvent: (event: Omit<Event, 'id' | 'ngoId' | 'ngoName'>) => void;
  updateEvent: (id: string, event: Partial<Event>) => void;
  deleteEvent: (id: string) => void;
  registerForEvent: (eventId: string, volunteerName: string, phoneNumber: string) => boolean;
  unregisterFromEvent: (eventId: string) => boolean;
  getEventRegistrations: (eventId: string) => Registration[];
  setTheme: (theme: 'light' | 'dark') => void;
  setLocationGranted: (granted: boolean) => void;
  setUserLocation: (location: { lat: number; lng: number } | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [theme, setThemeState] = useState<'light' | 'dark'>('light');
  const [locationGranted, setLocationGranted] = useState(false);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    const savedUsers = localStorage.getItem('users');
    const savedEvents = localStorage.getItem('events');
    const savedRegistrations = localStorage.getItem('registrations');
    const savedTheme = localStorage.getItem('theme');

    if (savedUser) setUser(JSON.parse(savedUser));
    if (savedUsers) setUsers(JSON.parse(savedUsers));
    if (savedEvents) setEvents(JSON.parse(savedEvents));
    if (savedRegistrations) setRegistrations(JSON.parse(savedRegistrations));
    if (savedTheme) setThemeState(savedTheme as 'light' | 'dark');
  }, []);

  // Apply theme
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const login = (email: string, password: string): boolean => {
    const foundUser = users.find(u => u.email === email);
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('currentUser', JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const register = (name: string, email: string, password: string, role: 'ngo' | 'volunteer', organizationName?: string): boolean => {
    const existingUser = users.find(u => u.email === email);
    if (existingUser) return false;

    const newUser: User = {
      id: Date.now().toString(),
      name,
      email,
      role,
      organizationName: role === 'ngo' ? organizationName : undefined,
    };

    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem('users', JSON.stringify(updatedUsers));
    
    setUser(newUser);
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('currentUser');
  };

  const addEvent = (event: Omit<Event, 'id' | 'ngoId' | 'ngoName'>) => {
    if (!user || user.role !== 'ngo') return;

    const newEvent: Event = {
      ...event,
      id: Date.now().toString(),
      ngoId: user.id,
      ngoName: user.organizationName || user.name,
    };

    const updatedEvents = [...events, newEvent];
    setEvents(updatedEvents);
    localStorage.setItem('events', JSON.stringify(updatedEvents));
  };

  const updateEvent = (id: string, eventUpdate: Partial<Event>) => {
    const updatedEvents = events.map(e => e.id === id ? { ...e, ...eventUpdate } : e);
    setEvents(updatedEvents);
    localStorage.setItem('events', JSON.stringify(updatedEvents));
  };

  const deleteEvent = (id: string) => {
    const updatedEvents = events.filter(e => e.id !== id);
    setEvents(updatedEvents);
    localStorage.setItem('events', JSON.stringify(updatedEvents));

    const updatedRegistrations = registrations.filter(r => r.eventId !== id);
    setRegistrations(updatedRegistrations);
    localStorage.setItem('registrations', JSON.stringify(updatedRegistrations));
  };

  const registerForEvent = (eventId: string, volunteerName: string, phoneNumber: string): boolean => {
    if (!user || user.role !== 'volunteer') return false;

    // Check if already registered
    const alreadyRegistered = registrations.find(
      r => r.eventId === eventId && r.volunteerId === user.id
    );
    if (alreadyRegistered) return false;

    const newRegistration: Registration = {
      id: Date.now().toString(),
      eventId,
      volunteerId: user.id,
      volunteerName,
      phoneNumber,
    };

    const updatedRegistrations = [...registrations, newRegistration];
    setRegistrations(updatedRegistrations);
    localStorage.setItem('registrations', JSON.stringify(updatedRegistrations));
    return true;
  };

  const unregisterFromEvent = (eventId: string): boolean => {
    if (!user || user.role !== 'volunteer') return false;

    // Check if registered
    const registration = registrations.find(
      r => r.eventId === eventId && r.volunteerId === user.id
    );
    if (!registration) return false;

    const updatedRegistrations = registrations.filter(
      r => !(r.eventId === eventId && r.volunteerId === user.id)
    );
    setRegistrations(updatedRegistrations);
    localStorage.setItem('registrations', JSON.stringify(updatedRegistrations));
    return true;
  };

  const getEventRegistrations = (eventId: string): Registration[] => {
    return registrations.filter(r => r.eventId === eventId);
  };

  const setTheme = (newTheme: 'light' | 'dark') => {
    setThemeState(newTheme);
    localStorage.setItem('theme', newTheme);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        users,
        events,
        registrations,
        theme,
        locationGranted,
        userLocation,
        login,
        register,
        logout,
        addEvent,
        updateEvent,
        deleteEvent,
        registerForEvent,
        unregisterFromEvent,
        getEventRegistrations,
        setTheme,
        setLocationGranted,
        setUserLocation,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};
