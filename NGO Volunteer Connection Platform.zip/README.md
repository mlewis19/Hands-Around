
  # NGO Volunteer Connection Platform

  This is a code bundle for NGO Volunteer Connection Platform. The original project is available at https://www.figma.com/design/B2gx2awva0fucyPofTRknH/NGO-Volunteer-Connection-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  